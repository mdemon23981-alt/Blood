import React, { useState } from "react";

function App() {
  const [donors, setDonors] = useState([]);
  const [requests, setRequests] = useState([]);

  const [donorForm, setDonorForm] = useState({ name: "", group: "", contact: "" });
  const [requestForm, setRequestForm] = useState({ name: "", group: "", contact: "" });

  const handleDonorSubmit = (e) => {
    e.preventDefault();
    if (!donorForm.name || !donorForm.group || !donorForm.contact) return;
    setDonors([...donors, donorForm]);
    setDonorForm({ name: "", group: "", contact: "" });
  };

  const handleRequestSubmit = (e) => {
    e.preventDefault();
    if (!requestForm.name || !requestForm.group || !requestForm.contact) return;
    setRequests([...requests, requestForm]);
    setRequestForm({ name: "", group: "", contact: "" });
  };

  return (
    <div className="min-h-screen bg-red-50 p-6">
      <h1 className="text-3xl font-bold text-center text-red-600 mb-8">
        🩸 Blood Connect
      </h1>

      {/* Donor Form */}
      <div className="bg-white shadow-md rounded-2xl p-6 mb-8">
        <h2 className="text-xl font-semibold text-red-500 mb-4">রক্ত দান করুন</h2>
        <form onSubmit={handleDonorSubmit} className="space-y-3">
          <input
            type="text"
            placeholder="নাম"
            value={donorForm.name}
            onChange={(e) => setDonorForm({ ...donorForm, name: e.target.value })}
            className="w-full border p-2 rounded-lg"
          />
          <input
            type="text"
            placeholder="রক্তের গ্রুপ (যেমনঃ A+)"
            value={donorForm.group}
            onChange={(e) => setDonorForm({ ...donorForm, group: e.target.value })}
            className="w-full border p-2 rounded-lg"
          />
          <input
            type="text"
            placeholder="যোগাযোগ নাম্বার"
            value={donorForm.contact}
            onChange={(e) => setDonorForm({ ...donorForm, contact: e.target.value })}
            className="w-full border p-2 rounded-lg"
          />
          <button
            type="submit"
            className="bg-red-500 text-white px-4 py-2 rounded-lg w-full"
          >
            Donor হিসেবে যুক্ত করুন
          </button>
        </form>
      </div>

      {/* Donor List */}
      <div className="bg-white shadow-md rounded-2xl p-6 mb-8">
        <h2 className="text-xl font-semibold text-red-500 mb-4">ডোনার লিস্ট</h2>
        {donors.length === 0 ? (
          <p className="text-gray-500">কোনো ডোনার নেই</p>
        ) : (
          <ul className="space-y-2">
            {donors.map((d, index) => (
              <li key={index} className="border p-3 rounded-lg">
                <span className="font-bold">{d.name}</span> — {d.group} — 📞{" "}
                {d.contact}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Request Form */}
      <div className="bg-white shadow-md rounded-2xl p-6 mb-8">
        <h2 className="text-xl font-semibold text-red-500 mb-4">রক্ত প্রয়োজন?</h2>
        <form onSubmit={handleRequestSubmit} className="space-y-3">
          <input
            type="text"
            placeholder="নাম"
            value={requestForm.name}
            onChange={(e) => setRequestForm({ ...requestForm, name: e.target.value })}
            className="w-full border p-2 rounded-lg"
          />
          <input
            type="text"
            placeholder="রক্তের গ্রুপ (যেমনঃ O+)"
            value={requestForm.group}
            onChange={(e) => setRequestForm({ ...requestForm, group: e.target.value })}
            className="w-full border p-2 rounded-lg"
          />
          <input
            type="text"
            placeholder="যোগাযোগ নাম্বার"
            value={requestForm.contact}
            onChange={(e) => setRequestForm({ ...requestForm, contact: e.target.value })}
            className="w-full border p-2 rounded-lg"
          />
          <button
            type="submit"
            className="bg-green-500 text-white px-4 py-2 rounded-lg w-full"
          >
            Request করুন
          </button>
        </form>
      </div>

      {/* Request List */}
      <div className="bg-white shadow-md rounded-2xl p-6">
        <h2 className="text-xl font-semibold text-green-600 mb-4">রক্তের রিকোয়েস্ট</h2>
        {requests.length === 0 ? (
          <p className="text-gray-500">কোনো রিকোয়েস্ট নেই</p>
        ) : (
          <ul className="space-y-2">
            {requests.map((r, index) => (
              <li key={index} className="border p-3 rounded-lg">
                <span className="font-bold">{r.name}</span> — {r.group} — 📞{" "}
                {r.contact}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default App;
